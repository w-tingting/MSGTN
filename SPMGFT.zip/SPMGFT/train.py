#!/usr/bin/python
# -*- coding:UTF-8 -*-
"""
Author: Tingting Wang
Time: 20240621
Function: Train a Multi-scale Graph Transformer Network for HSI
"""
import random
import time

import numpy as np
import pytorch_warmup as warmup
import scipy.io as scio
import torch
import torch.nn.functional as F
from sklearn import preprocessing, metrics
from torch.optim import lr_scheduler

import show_maps
from config import parameter_parser
from model import MultiGraphTrans
from vit_gcn import ViT
# from skimage.segmentation import mark_boundaries

torch.backends.cudnn.benchmark = False
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#################################### Matrics Setting###################################
OA_ALL = []
AA_ALL = []
KPP_ALL = []
AVG_ALL = []
Train_Time_ALL = []
Test_Time_ALL = []

Seed_List = [1330, 1331, 1332, 1333, 1334]  # 随机种子点

#################################### Matrics End ###################################
args = parameter_parser()
dataset_name = args.dataset
learning_rate = args.lr
train_ratio = args.train_ratio
val_ratio = args.val_ratio
max_epoch = args.epochs

if dataset_name == 'paviaU':
    groundtruth_filename = './datasets/paviaU_gt.mat'
    groundtruth_mat = 'paviaU_gt'
    data_filename = './datasets/paviaU.mat'
    HSI_mat = 'paviaU'
    RGB_bands = np.array([55, 41, 12])
    max_epoch = 200
    learning_rate = 1e-3
elif dataset_name == 'indian':
    groundtruth_filename = './datasets/indian_pines_gt.mat'
    groundtruth_mat = 'indian_pines_gt'
    data_filename = './datasets/indian_pines_corrected.mat'
    HSI_mat = 'indian_pines_corrected'
    RGB_bands = np.array([43, 21, 11])
    max_epoch = 200
    train_ratio = 0.05
    val_ratio = 0.05
elif dataset_name == 'salina':
    groundtruth_filename = './datasets/salinas_gt.mat'
    groundtruth_mat = 'salinas_gt'
    data_filename = './datasets/salinas_corrected.mat'
    HSI_mat = 'salinas_corrected'
    RGB_bands = np.array([55, 41, 12])
    max_epoch = 200
elif dataset_name == 'paviaC':
    groundtruth_filename = './datasets/pavia_gt.mat'
    groundtruth_mat = 'pavia_gt'
    data_filename = './datasets/pavia.mat'
    HSI_mat = 'pavia'
    RGB_bands = np.array([55, 41, 12])
    max_epoch = 200

elif dataset_name == 'WHU_HongHu':
    groundtruth_filename = './datasets/WHU_Hi_HongHu_gt.mat'
    groundtruth_mat = 'WHU_Hi_HongHu_gt'
    data_filename = './datasets/WHU_Hi_HongHu.mat'
    HSI_mat = 'WHU_Hi_HongHu'
    RGB_bands = np.array([120, 60, 20])
    max_epoch = 200
    train_ratio = 0.01
    val_ratio = 0.01
elif dataset_name == 'Houston13':
    groundtruth_filename = './datasets/Houston13_gt.mat'
    groundtruth_mat = 'name'
    data_filename = './datasets/Houston13.mat'
    HSI_mat = 'ans'
    RGB_bands = np.array([15, 63, 52])
    max_epoch = 200
    train_ratio = 0.1
    val_ratio = 0.1

import h5py
try:
    labelfile = scio.loadmat(groundtruth_filename)  # 'PaviaU_gt.mat'Indian_pines_gt
    Groundtruth = labelfile.get(groundtruth_mat)  # paviaU_gt indian_pines_gt
except Exception:

    labelfile = h5py.File(groundtruth_filename, 'r')
    Groundtruth = labelfile['ans'][:]

Height, Width = Groundtruth.shape

try:
    HSIfile = scio.loadmat(data_filename)  # PaviaU.mat Indian_pines_corrected
    HSI = HSIfile.get(HSI_mat)  # paviaU indian_pines_corrected
except Exception:
    HSIfile = h5py.File(data_filename, 'r')  # PaviaU.mat Indian_pines_corrected
    HSI = HSIfile['ori_data'][:]  # paviaU indian_pines_corrected
    HSI = np.transpose(HSI, [1,2,0])

Bands = HSI.shape[2]

data = np.reshape(HSI, [Height * Width, Bands])
print("data:", data.shape)

minMax = preprocessing.StandardScaler()
data = minMax.fit_transform(data)
samples_type = 'ratio'

class_count = int(np.amax(Groundtruth))

train_rand_idx = np.empty((0, 2), dtype='int')
val_rand_idx = np.empty((0, 2), dtype='int')
test_idx = np.empty((0, 2), dtype='int')
train_label_weight = np.zeros(class_count)
val_label_weight = np.zeros(class_count)
test_label_weight = np.zeros(class_count)

Groundtruth = np.reshape(Groundtruth, [Height * Width])
random.seed(200)
np.random.seed(200)
torch.cuda.manual_seed(200)

if samples_type == 'ratio':
    for i in range(class_count):
        idx = np.where(Groundtruth == i + 1)[-1]
        # print("idx:", idx.shape)
        label_tmp = np.ones(len(idx), dtype='int') * (i + 1)
        tmp = np.concatenate((idx[:][np.newaxis].T, label_tmp[np.newaxis].T), axis=1)
        test_idx = np.concatenate((test_idx, tmp), axis=0)
        test_label_weight[i] = 1. / (len(idx) + 1e-4)

        samplesCount = len(idx)
        rand_list = [i for i in range(samplesCount)]  # 用于随机的列表
        rand_idx = random.sample(rand_list,
                                 (np.ceil(samplesCount * train_ratio) + np.ceil(samplesCount * val_ratio)).astype(
                                     'int32'))  # 随机数数量 四舍五入(改为上取整)
        rand_real_idx_per_class = idx[rand_idx]
        label_tmp = np.ones(len(idx[rand_idx]), dtype='int') * (i + 1)
        tmp = np.concatenate((idx[rand_idx][np.newaxis].T, label_tmp[np.newaxis].T), axis=1)
        train_rand_idx = np.concatenate((train_rand_idx, tmp[:int(np.ceil(samplesCount * train_ratio)), :]), axis=0)
        val_rand_idx = np.concatenate((val_rand_idx, tmp[int(np.ceil(samplesCount * train_ratio)):, :]), axis=0)
        train_label_weight[i] = 1. / (np.ceil(samplesCount * train_ratio) + 1.)
        val_label_weight[i] = 1. / (np.ceil(samplesCount * val_ratio) + 1.)

train_label_mask = np.zeros(Height * Width, dtype='int')
train_label_mask[train_rand_idx[:, 0]] = np.ones(train_rand_idx.shape[0])

train_label_mat = np.zeros(Height * Width, dtype='int')
train_label_mat[train_rand_idx[:, 0]] = train_rand_idx[:, 1]
train_label_mat = np.reshape(train_label_mat, [Height, Width])
scio.savemat('Train_gt.mat', {'TRAIN_GT': train_label_mat})

val_label_mask = np.zeros(Height * Width, dtype='int')
val_label_mask[val_rand_idx[:, 0]] = np.ones(val_rand_idx.shape[0])

test_label_mask = np.zeros(Height * Width, dtype='int')
test_label_mask[test_idx[:, 0]] = np.ones(test_idx.shape[0])
# 0 to 255
Y = (Groundtruth - 1).astype(np.int32)

train_label_mask = torch.from_numpy(train_label_mask.astype(bool)).to(device)
test_label_mask = torch.from_numpy(test_label_mask.astype(bool)).to(device)
val_label_mask = torch.from_numpy(val_label_mask.astype(bool)).to(device)
train_label_weight = torch.from_numpy(train_label_weight.astype(np.float32)).to(device)
val_label_weight = torch.from_numpy(val_label_weight.astype(np.float32)).to(device)
test_label_weight = torch.from_numpy(test_label_weight.astype(np.float32)).to(device)
Y_label = torch.from_numpy(Y.astype(np.int64)).to(device)

HSI_n = np.reshape(data, [Height, Width, -1])
# tensor
net_input = torch.from_numpy(np.array(HSI_n, np.float32)).to(device)


def evaluate_performance(network_output, label, method=None, require_AA_KPP=False, printFlag=True):
    if not require_AA_KPP:
        with torch.no_grad():
            _, pred = network_output.max(dim=1)
            correct = float(pred.eq(label).sum().item())
            OA = correct / (label != 255).float().sum()
            return OA
    else:
        with torch.no_grad():
            # OA
            _, pred = network_output.max(dim=1)
            correct = float(pred.eq(label).sum().item())
            OA = correct / (label != 255).float().sum()
            OA = OA.cpu().numpy()
            y_pred = pred.cpu().numpy()
            gt_label = label.cpu().numpy()
            # Kappa
            kappa = metrics.cohen_kappa_score(y_pred, gt_label)
            # confusion_matrix
            confusion_matrix = metrics.confusion_matrix(gt_label, y_pred)
            producer_acc = np.diag(confusion_matrix) / np.sum(confusion_matrix, axis=1)
            AA = np.average(producer_acc)
            if printFlag:
                # print("test OA=", OA, 'test AA=', AA, 'kpp=', kappa, 'confusion matrix=', confusion_matrix)
                print("test OA={:.4} AA={:.4} kpp={:.4}".format(OA, AA, kappa))
                print('acc per class:')
                print(producer_acc)

            OA_ALL.append(OA)
            AA_ALL.append(AA)
            KPP_ALL.append(kappa)
            AVG_ALL.append(producer_acc)

            # save
            f = open('results/' + method + '-' + dataset_name + '_results.txt', 'a+')
            str_results = '\n======================' \
                          + " learning rate=" + str(learning_rate) \
                          + " epochs=" + str(max_epoch) \
                          + " train ratio=" + str(train_ratio) \
                          + " val ratio=" + str(val_ratio) \
                          + " ======================" \
                          + "\nOA=" + str(OA) \
                          + "\nAA=" + str(AA) \
                          + '\nkpp=' + str(kappa) \
                          + '\nacc per class:' + str(producer_acc) \
                          + "\nconfusion matrix:" + str(confusion_matrix) + "\n"

            f.write(str_results)
            f.close()
            return OA


for curr_seed in Seed_List:
    torch.cuda.empty_cache()  # GPU memory released
    layer_num = 5
    net = MultiGraphTrans(args, Bands, class_count, layer_num, num_spixels=args.num_spixels, in_channel=64)
    net.to(device)

    import apex
    optimizer = apex.optimizers.FusedAdam(net.parameters(), lr=learning_rate, betas=(0.9, 0.99),
                                          weight_decay=args.weight_decay)
    scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=5e-5, last_epoch=-1)
    warmup_scheduler = warmup.UntunedLinearWarmup(optimizer)

    tr_net = ViT(
        n_gcn=96,
        num_patches=3438,
        num_classes=class_count,
        dim=64,
        depth=3,
        heads=4,
        mlp_dim=8,
        dropout=0.1,
        emb_dropout=0.1,
    )
   
    tr_net = tr_net.to(device)
   
    optimizer2 = apex.optimizers.FusedAdam(tr_net.parameters(), lr=learning_rate, betas=(0.9, 0.99),
                                          weight_decay=args.weight_decay)
    scheduler2 = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer2, T_max=args.epochs, eta_min=5e-5, last_epoch=-1)

    ####################################################################################################################
    best_loss = 99999
    best_OA = 0
    torch.cuda.empty_cache()

    train_loss = []
    train_count = []
    train_acc = []

    print('########################### {} Train start ################################'.format(curr_seed))
    tic2 = time.time()
    net.train()
    tr_net.train()

    for epoch in range(0, max_epoch + 1):
        optimizer.zero_grad()
        optimizer2.zero_grad()

        data = net_input.permute(2, 0, 1)
        data = data.unsqueeze(0)

        X_data = data.float().to(device)
        # forward
        output, Q_T = net(X_data)
        # Transformer
        output = tr_net(output.to(device))  # 3123,9
        output = torch.matmul(Q_T, output.squeeze(0).to(device))

        # loss function
        loss = F.cross_entropy(output[train_label_mask], Y_label[train_label_mask], train_label_weight)

        train_loss.append(loss.item())
        train_count.append(epoch)
        # backward
        loss.backward()
        optimizer.step()
        optimizer2.step()
        with warmup_scheduler.dampening():
            scheduler.step()
        scheduler2.step()

        if epoch % 10 == 0:
            with torch.no_grad():
                net.eval()
                tr_net.eval()
                # forward
                output, Q_T = net(X_data)

                # Transformer
                output = tr_net(output.to(device))  # 3123,9
                output = torch.matmul(Q_T, output.squeeze(0).to(device))

                trainloss = F.cross_entropy(output[train_label_mask], Y_label[train_label_mask], train_label_weight)
                trainOA = evaluate_performance(output[train_label_mask], Y_label[train_label_mask])
                valloss = F.cross_entropy(output[val_label_mask], Y_label[val_label_mask], val_label_weight)
                valOA = evaluate_performance(output[val_label_mask], Y_label[val_label_mask])
                print("{}\ttrain loss={:.4} \t train OA={:.4}  val loss={:.4} \t val OA={:.4} \t lr={:.4}".format(
                    str(epoch + 1),
                    trainloss,
                    trainOA,
                    valloss, valOA, optimizer2.param_groups[0]["lr"]))

                if valOA > best_OA or best_loss > valloss:
                    best_loss = valloss
                    best_OA = valOA
                    torch.save(net.state_dict(), "model/net_best_model.pt")
                    torch.save(tr_net.state_dict(), "model/tr_net_best_model.pt")
                    # print('save model...')

            torch.cuda.empty_cache()

    toc2 = time.time()
    training_time = toc2 - tic2
    Train_Time_ALL.append(training_time)

    print('Train finished')
    print("Training costs time: {}".format(training_time))
    torch.cuda.empty_cache()

    print('Test start')
    tic3 = time.time()
    with torch.no_grad():
        net.load_state_dict(torch.load("model/net_best_model.pt"))
        tr_net.load_state_dict(torch.load("model/tr_net_best_model.pt"))
        net.eval()
        tr_net.eval()
        # forward
        output, Q_T = net(X_data)
        # Transformer
        output = tr_net(output)  # 3123,9
        output = torch.matmul(Q_T, output.squeeze(0))
        

        toc3 = time.time()
        testing_time = toc3 - tic3

        testloss = F.cross_entropy(output[test_label_mask], Y_label[test_label_mask], test_label_weight)
        testOA = evaluate_performance(output[test_label_mask], Y_label[test_label_mask], method='MultiGraphTrans',
                                      require_AA_KPP=True)

        print("out test loss={:.4}\t test OA={:.4} ".format(testloss, testOA))
        print('OA=', np.array(OA_ALL))
        print("test time={:.4}".format(testing_time))

        classification_map = torch.argmax(output, 1).reshape([Height, Width]).cpu() + 1
        gt = Groundtruth.reshape((Height, Width))

        show_maps.show_pred(classification_map, gt, class_count, dataset_name, "results/")

        Test_Time_ALL.append(testing_time)
    print('Test finished')
    torch.cuda.empty_cache()
    del net
    del tr_net

OA_ALL = np.array(OA_ALL)
AA_ALL = np.array(AA_ALL)
KPP_ALL = np.array(KPP_ALL)
AVG_ALL = np.array(AVG_ALL)
Train_Time_ALL = np.array(Train_Time_ALL)
Test_Time_ALL = np.array(Test_Time_ALL)

print("\ntrain_ratio={}".format(train_ratio),
      "\n==============================================================================")
print('OA=', OA_ALL)
print('OA=', np.mean(OA_ALL) * 100, '+-', np.std(OA_ALL) * 100)
print('AA=', np.mean(AA_ALL) * 100, '+-', np.std(AA_ALL) * 100)
print('Kpp=', np.mean(KPP_ALL) * 100, '+-', np.std(KPP_ALL) * 100)
print('AVG=', np.mean(AVG_ALL, 0) * 100, '+-', np.std(AVG_ALL, 0) * 100)
print("Average training time:{}".format(np.mean(Train_Time_ALL)))
print("Average testing time:{}".format(np.mean(Test_Time_ALL)))

# 保存数据信息
f = open('results/' + dataset_name + '{}_results.txt'.format(train_ratio), 'a+')
str_results = '\n\n************************************************' \
              + "\ntrain_ratio={}".format(train_ratio) \
              + '\nOA=' + str(np.mean(OA_ALL)) + '+-' + str(np.std(OA_ALL)) \
              + '\nAA=' + str(np.mean(AA_ALL)) + '+-' + str(np.std(AA_ALL)) \
              + '\nKpp=' + str(np.mean(KPP_ALL)) + '+-' + str(np.std(KPP_ALL)) \
              + '\nAVG=' + str(np.mean(AVG_ALL, 0)) + '+-' + str(np.std(AVG_ALL, 0)) \
              + "\nAverage training time:{}".format(np.mean(Train_Time_ALL)) \
              + "\nAverage testing time:{}".format(np.mean(Test_Time_ALL))
f.write(str_results)
f.close()
