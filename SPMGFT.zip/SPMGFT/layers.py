import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from utils.ssn_sp import ssn_iter
from torch_geometric.utils.sparse import dense_to_sparse

np.set_printoptions(threshold=np.inf)


class Conv3x3BNReLU(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv3x3BNReLU, self).__init__()
        self.block1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3,
                      stride=1, padding=1, bias=False),
            nn.GroupNorm(16, out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = self.block1(x)
        return x


def get_adj_matrix(segments, features, sigma):
    """
       Get adjacency matrix from graph.
       Args:
           segments (Tensor[B, H, W]): A RAG (Region Adjacency Graph).
           features (Tensor[B, N, C]): A tensor.
           sigma (float): sigma.
       Returns:
           A Tensor(B, N, N) represents adjacency matrix.
    """
    b, n, c = features.shape
    if segments.is_cuda and not torch.is_floating_point(segments):
        segments = segments.float()
    max_indexes = F.max_pool2d(segments.unsqueeze(1), 2, stride=1).view(b, -1)
    min_indexes = -F.max_pool2d(-segments.unsqueeze(1), 2, stride=1).view(b, -1)
    if torch.is_floating_point(max_indexes):
        max_indexes = max_indexes.int()
    min_indexes = min_indexes.int()
    adj = torch.zeros(b, n, n, dtype=features.dtype, device=segments.device)
    batch_indexes = torch.arange(b).view(b, 1, 1)
    c_indexes = torch.arange(c)
    left_mix_indexes = torch.cat((max_indexes, min_indexes), dim=-1)
    right_mix_indexes = torch.cat((min_indexes, max_indexes), dim=-1)
    n_indexes = left_mix_indexes * n + right_mix_indexes
    left_mix_features = features[batch_indexes.long(), left_mix_indexes.long().unsqueeze(-1), c_indexes.long()]
    right_mix_features = features[batch_indexes.long(), right_mix_indexes.long().unsqueeze(-1), c_indexes.long()]
    adj.view(b, -1)[batch_indexes.long(), n_indexes.long()] = (
                                                                          left_mix_indexes.long() != right_mix_indexes.long()) * torch.exp(
        -(left_mix_features.long() - right_mix_features.long()).pow(2).sum(-1) / sigma ** 2)
    return adj


class SSN(nn.Module):
    def __init__(self, args, num_spixels):
        super(SSN, self).__init__()
        self.args = args
        self.num_spixels = num_spixels

        self.pool = nn.AdaptiveAvgPool2d((1, 1))

    def forward(self, xs):
        x = []
        batch, b, h, w = xs.size()
        x.append(xs)
        x_scale_2 = nn.AdaptiveAvgPool2d((h//2, w//2))(xs)
        x.append(x_scale_2)
        x_scale_4 = nn.AdaptiveAvgPool2d((h // 4, w // 4))(xs)
        x.append(x_scale_4)
        x_scale_6 = nn.AdaptiveAvgPool2d((h // 6, w // 6))(xs)
        x.append(x_scale_6)
        x_scale_8 = nn.AdaptiveAvgPool2d((h // 8, w // 8))(xs)
        x.append(x_scale_8)
        x_scale_10 = nn.AdaptiveAvgPool2d((h // 10, w // 10))(xs)
        x.append(x_scale_10)

        num_scale = len(self.num_spixels)

        Q_list = []
        edge_index_list = []
        superpixels_flatten_list = []

        for k in range(num_scale):
            Q, segments, S, n_spixels = ssn_iter(x[k], num_spixels=self.num_spixels[k], n_iter=10)
            # print("seg:", segments.shape)
            # print("S:", S.shape)
            if self.args.save_boundaries is True:
                import matplotlib.pyplot as plt
                from skimage.segmentation import mark_boundaries
                img = x[k].permute(0, 2, 3, 1).squeeze(0)
                # print(img.shape)
                y = segments.squeeze(0)

                img = img.cpu().detach().numpy()
                y = y.cpu().detach().numpy()
                y = y.reshape(img.shape[0], img.shape[1])
                print(y.shape)
                # out = img[:,:,[0,1,2]]
                out = mark_boundaries(img[:, :, [0, 1, 2]], y)
                # out = (img[:, :, [0, 1, 2]] - np.min(img[:, :, [0, 1, 2]])) / (np.max(img[:, :, [0, 1, 2]]) -
                #                                                                np.min(img[:, :, [0, 1, 2]]))
                # plt.figure()
                # plt.imshow(out)
                # # plt.savefig('segments/{}.png'.format(epoch))
                # plt.show()

                plt.axis('off')
                height, width = y.shape

                plt.gcf().set_size_inches(width / 100.0, height / 100.0)  # 输出width*height像素
                plt.gca().xaxis.set_major_locator(plt.NullLocator())
                plt.gca().yaxis.set_major_locator(plt.NullLocator())
                plt.subplots_adjust(top=1, bottom=0, right=0.999, left=0, hspace=0, wspace=0)
                # plt.margins(0, 0)
                plt.xticks([])  # 关闭刻度
                plt.yticks([])
                plt.imshow(out)  # 标签图
                save_path = 'segments/' + self.args.dataset + '_{}_{}_boundaries.png'.format(k, self.num_spixels[k])
                plt.savefig(save_path, dpi=300)

            S = S.permute(0, 2, 1)
            batch, b, h, w = x[k].size()
            segments = segments.reshape(1, h, w)
            A = get_adj_matrix(segments, S, sigma=10)
            edge_index, _ = dense_to_sparse(A.squeeze())

            Q_list.append(Q)
            edge_index_list.append(edge_index)
            superpixels_flatten_list.append(S)

        return Q_list, edge_index_list, superpixels_flatten_list

