import argparse

def parameter_parser():
    ############ parameters setting ############
    parser = argparse.ArgumentParser(description="Network Trn_val_Tes")
    ## dataset setting
    parser.add_argument('--dataset', type=str, default='indian',
                        choices=['indian', 'paviaU', 'paviaC', 'salina', 'ksc', 'Houston13'],
                        help='dataset name')
    ## normalization setting
    parser.add_argument('--norm', type=str, default='norm',
                        choices=['std', 'norm'],
                        help='nomalization mode')
    parser.add_argument('--mi', type=int, default=-1,
                        help='min normalization range')
    parser.add_argument('--ma', type=int, default=1,
                        help='max normalization range')
    ## experimental setting
    parser.add_argument('--sync_bn', type=str, default='True',
                        choices=['True', 'False'], help='synchronized batchNorm')
    parser.add_argument('--use_apex', type=str, default='False',
                        choices=['True', 'False'], help='mixed-precision training')
    parser.add_argument('--opt_level', type=str, default='O1',
                        choices=['O0', 'O1', 'O2'], help='mixed-precision')
    parser.add_argument('--input_mode', type=str, default='whole',
                        choices=['whole', 'part'], help='input setting')
    parser.add_argument('--input_size', nargs='+', type=int, default=128)
    parser.add_argument('--overlap_size', type=int, default=56,
                        help='size of overlap')
    parser.add_argument('--experiment-num', type=int, default=10,
                        help='experiment trials number')
    parser.add_argument('--lr', type=float, default=0.01,
                        help='learning rate')
    parser.add_argument('--epochs', type=int, default=500,
                        help='number of epochs to train')
    parser.add_argument('--batch-size', type=int, default=1,
                        help='input batch size for training')
    parser.add_argument('--val-batch-size', type=int, default=1,
                        help='input batch size for validation')
    parser.add_argument('--weight-decay', type=float, default=5e-4,
                        help='weight decay')
    parser.add_argument('--workers', type=int, default=2,
                        help='workers num')
    parser.add_argument('--ignore_label', type=int, default=255,
                        help='ignore label')
    parser.add_argument('--print_freq', type=int, default=3,
                        help='print frequency')
    parser.add_argument("--resume", type=str, help="model path.")
    # model setting
    # parser.add_argument('--num_spixels', type=int, default=[512, 256, 128],
    #                     help='spatial group number')
    # [1024, 768, 640, 576, 528][100,64,32,16,4][1024, 768, 640, 576, 528]
    parser.add_argument('--num_spixels', type=int, default=[1024, 768, 640, 576, 528],
                        help='spatial group number')
    parser.add_argument('--sample_type', type=str, default='same',
                        choices=['ratio', 'same'],
                        help='sample mode')
    parser.add_argument('--train_ratio', type=float, default=0.01,
                        help='sample ratio')
    parser.add_argument('--val_ratio', type=float, default=0.01,
                        help='val ratio')
    parser.add_argument('--train_samples_per_class', type=int, default=200,
                        help='sample num')
    parser.add_argument('--val_samples', type=int, default=200,
                        help='sample num')
    #################################### VIB ##################################
    parser.add_argument("--backbone", type=str, default="GCN",
                        help="GCN, GAT, GIN")
    parser.add_argument("--graph_type", type=str, default="prob",
                        help="epsilonNN, KNN, prob")
    parser.add_argument("--graph_metric_type", type=str, default="mlp")
    parser.add_argument("--repar", type=bool, default=True,
                        help="Default is True.")
    parser.add_argument("--num_layers", type=int, default=2,
                        help="Default is 2.")
    parser.add_argument("--hidden_dim", type=int, default=16,
                        help="Default is 16.")
    parser.add_argument("--beta", type=float, default=0.00001,
                        help="Default is 1e-5")
    parser.add_argument("--IB_size", type=int, default=16,
                        help="Default is 16.")
    parser.add_argument("--num_per", type=int, default=16,
                        help="Default is 16")
    parser.add_argument("--feature_denoise", type=bool, default=False,
                        help="Default is False.")
    parser.add_argument("--top_k", type=int, default=10,
                        help="Default is 10.")
    parser.add_argument("--epsilon", type=float, default=0.3,
                        help="Default is 0.3.")
    parser.add_argument("--graph_skip_conn", type=float, default=0.0,
                        help="Default is 0.0.")
    parser.add_argument("--graph_include_self", type=bool, default=True,
                        help="Default is True.")
    parser.add_argument("--save_boundaries", type=bool, default=False,
                        help="Default is True.")
    parser.add_argument('--pca_bands', type=int, default=70,
                        help='PCA reduce dimension')
    parser.add_argument('--gamma', type=float, default=0.9, help='gamma')

    return parser.parse_args()
