import scipy.io as scio
import numpy as np
import os
from sklearn.decomposition import PCA
import random
import h5py


data_path = './hong/data_HS_LR.mat'
train_path = './hong/TrainImage.mat'
test_path = './hong/TestImage.mat'

    # 载入数据
data = scio.loadmat(data_path)['data_HS_LR']
tr_lab = scio.loadmat(train_path)['TrainImage']
te_lab = scio.loadmat(test_path)['TestImage']



print(data.shape)
print(tr_lab.shape)
print(te_lab.shape)