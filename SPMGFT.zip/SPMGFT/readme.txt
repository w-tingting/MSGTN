run the code:
python train.py

install:

torch==2.1.0
torch_geometric==2.5.3
apex
